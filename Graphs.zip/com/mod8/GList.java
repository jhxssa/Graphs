package com.mod8;
import java.util.Iterator;
import java.util.LinkedList;
public class GList {
	//adjacency list
		int n;
		LinkedList <Integer> [] al; //array of LL
		
		public GList (int n) {
			this.n=n;
			al = new LinkedList[n];
			for (int i =0; i<al.length; i++) {
				al[i] = new LinkedList<Integer>();
			}
		}
			public void addEdge (int start, int end) {
				al[start].add(end);
			}
			public void displayGraph ( ) {
				for (int i = 0; i < al.length; i++) {
					System.out.print(i + ": ");
					for (int j = 0; j<al[i].size(); j++) {
						System.out.print(al[i].get(j) + " ");
					}
					System.out.println();
				}
		}
	}


