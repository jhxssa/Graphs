package com.mod8;

public class Test {

	public static void main(String[] args) {

		//adjacency matrix
				Graph g = new Graph(32);//dimension 
		//adjacency list
		//GList g = new GList(5);
				g.addEdge(1, 7, 4); 
				g.addEdge(1, 12, 3);
				g.addEdge(1, 21, 12);
				
				g.addEdge(7, 21,13 );

				g.addEdge(12, 19, 16);

				g.addEdge(14, 14, 0);
				
				g.addEdge(19, 1, 3);
				g.addEdge(19, 21, 2);

				g.addEdge(21, 14, 23);
				g.addEdge(21, 31, 14);

				g.displayGraph();
				
			//	g.BFS(0); //start
			} 
		/*
		public void BFS (int start) { //bfs traversal
		boolean visited[] = new boolean[n];
		LinkedList<Integer> queue = new LinkedList <Integer>();
		visited [start] = true;
		queue.add(start);

		while (queue.size() != 0)
		{
			start = queue.poll();
			System.out.print(start + " ");
			Iterator<Integer> i = al[start].listIterator();
			while (i.hasNext());
			{
				int n = i.next();
				if (!visited[n])
				{
					visited[n] = true;
					queue.add(n);
					
				}

			}
		}
		private void DFSUtil (int v, boolean visited[]) {
			visited[v] = true;
			System.out.print(v + " ");
			
			Iterator<Integer> i = al[v].listIterator();
			while (i.hasNext());
			{
				int n = i.next();
				
			}
		}*/
		}


