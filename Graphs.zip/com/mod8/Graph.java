package com.mod8;

public class Graph {
	
		int n; //nodes
		int [][] am; //2x2 array
		
		public Graph (int n) {
			this.n=n;
			am = new int [n][n];
			
		}
		
		public void addEdge (int start, int end, int weight) { //row=start  end=column
			am [start][end] = weight;
			
		}
		
		public void displayGraph() {
			for (int i = 0; i < am.length; i++) {
				System.out.print(i + ": ");
				for (int j =0; j < am[i].length; j++) {
					System.out.print(am[i][j]+ " "); //row and column
							
				}
				System.out.println();
			}
		}
	}


