module Graphs {
}